import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pages-blank',
  templateUrl: './pages-blank.component.html',
  styleUrls: ['./pages-blank.component.css']
})
export class PagesBlankComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
