import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pages-faq',
  templateUrl: './pages-faq.component.html',
  styleUrls: ['./pages-faq.component.css']
})
export class PagesFaqComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
