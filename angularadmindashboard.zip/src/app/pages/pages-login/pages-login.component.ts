import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pages-login',
  templateUrl: './pages-login.component.html',
  styleUrls: ['./pages-login.component.css']
})
export class PagesLoginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
